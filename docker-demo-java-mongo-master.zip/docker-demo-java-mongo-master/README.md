# docker-demo-java-mongo
