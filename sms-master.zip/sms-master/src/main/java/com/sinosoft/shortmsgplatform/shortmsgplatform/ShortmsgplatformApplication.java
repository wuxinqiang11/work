package com.sinosoft.shortmsgplatform.shortmsgplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;


@SpringBootApplication
public class ShortmsgplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShortmsgplatformApplication.class, args);
	}
}
